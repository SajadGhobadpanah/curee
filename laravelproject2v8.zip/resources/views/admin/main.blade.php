@component('admin.layouts.content',['title'=>'صفحه ی اصلی'])


    @slot('breadcromp')

        <li class="breadcrumb-item"><a href="#">صفحه ی اصلی</a></li>
    @endslot
    صفحه ی اصلی
@endcomponent
