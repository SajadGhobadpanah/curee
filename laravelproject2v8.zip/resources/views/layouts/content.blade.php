@include('layouts.header')


@include('layouts.navbar')

@include('layouts.sidebar')


@yield('index')
<br>
<!--//footer-->

@include('layouts.footer')

