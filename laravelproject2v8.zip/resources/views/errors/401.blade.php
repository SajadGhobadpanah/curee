<!doctype html>
<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    body{
        text-align: center;
        margin-top: 100px;
    }

</style>
<body style="background: #ddd" >


<div class="container">
    <div class="row">

        <div class="col-md-8 offset-4">
            <div class="text-center" style="margin: auto">

                <h1 class="text-danger text-center">دسترسی یه این صفحه امکان پذیر نیست! </h1>
                <a href="/" style="background: paleturquoise;padding: 2px;margin-bottom: 10px; ">بازگشت به صفحه ی اصلی</a>

                <img src="/images/404/401.jpg" alt="" width="100%">
            </div>
        </div>
    </div>
</div>

</body>
</html>
