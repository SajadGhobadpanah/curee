<?php
return [
    'types' => [
        'off' => 'غیر فعالسازی',
        'sms' => 'فعالسازی'

    ]
];
