<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('title'); ?>
محصولات
<?php $__env->stopSection(); ?>
<div class="container">

    <div class="row mb-4 mt-4">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 my-2">
                <div class="card  ">

                    <div class="card-header text-center">
                        <?php echo e($product->title); ?>

                    </div>

                    <div class="card-body">
                        <img src="<?php echo e($product->image); ?>" alt="" width="100%">
                    </div>

                    <div class="card-footer text-center">
                        <a href="<?php echo e(route('singleproduct',$product->id)); ?>"
                           class="btn btn-outline-blu btn-sm"><?php echo e($product->price); ?></a>
                        <?php if($product->percent): ?>
                            <sapn
                                style="background: #d90b31;color: #fff; padding: 2px;border-radius: 30%"><?php echo e($product->percent); ?> </sapn>
                            <span>%</span>
                        <?php endif; ?>
                    </div>

                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

</div>
</div>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/home/products.blade.php ENDPATH**/ ?>