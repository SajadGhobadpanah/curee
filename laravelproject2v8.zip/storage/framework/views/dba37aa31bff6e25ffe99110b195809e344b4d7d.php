<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="col-md-8 mr-2">
        <div class="row">

            <h3>نتایج جستجو برای <span class="text text-danger"><?php echo e(request('search')); ?></span></h3>

                <?php if($articles): ?>
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 my-2">
                        <div class="card p-2">
                            <div class="card-header">

                                <?php echo e($article->title); ?>

                            </div>

                            <div class="card-body">
                                <img src="<?php echo e($article->image); ?>" alt="" width="100%">

                            </div>

                            <div class="card-footer d-flex justify-content-between align-items-center">
                                <a href="<?php echo e(route('article.single',$article->id)); ?>" class="btn btn-outline-blu text-center">ادامه
                                    مطلب...</a>

                                <span style="float: left">   بازدید: <?php echo e($article->view_count); ?></span>
                            </div>

                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php else: ?>

                    <span> چیزی یافت نشد </span>
                    <?php endif; ?>

        </div>
    </div>


    </div>
<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/home/search.blade.php ENDPATH**/ ?>