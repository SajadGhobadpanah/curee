<?php $__env->startComponent('admin.layouts.content',['title'=>' مدیریت کاربران ']); ?>


    <?php $__env->slot('breadcromp'); ?>

        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.')); ?>">صفحه ی اصلی</a></li>
        <li class="breadcrumb-item active"><a>مدیریت کاربران</a></li>
    <?php $__env->endSlot(); ?>
    <div class="card">
        <div class="card-header ">

            <div class="card-tools ">
                <div class="input-group input-group-sm ">
                    <div class="d-flex align-items-center">
                        <?php if(request('search') || request('admin')): ?>
                            <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-outline-danger  ml-2">بازگشت
                            </a>
                        <?php endif; ?>
                        <a href="<?php echo e(request()->fullUrlWithQuery(['admin'=>1])); ?>" class="btn btn-outline-info  ml-2">کاربران
                            مدیر</a>
                        <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-outline-info  ml-2">ساخت کاربر جدید</a>
                        <form action="" class="d-flex">
                            <input type="text" name="search" class="form-control float-right "
                                   placeholder="جستجو" value="<?php echo e(request('search')); ?>">
                            <div class="input-group-append">
                                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
        <!-- /.card-header -->
        <div class="card-body table-responsive p-0">
            <table class="table table-hover my-2">
                <tbody>
                <tr>
                    <th>شماره کاربر</th>
                    <th>نام کاربر</th>
                    <th>تاریخ ثبت نام کاربر</th>
                    <th> وضعیت ایمیل</th>
                    <th>اقدامات</th>
                </tr>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e(jdate($user->created_at)->format('%B %d، %Y')); ?></td>
                        <td>
                            <?php if($user->email_verified_at): ?>

                                <span class="badge badge-success">تایید شده</span>

                            <?php else: ?>
                                <span class="badge badge-danger">تایید نشده</span>

                            <?php endif; ?>


                        </td>
                        <td class="d-flex">
                            
                            <a href="<?php echo e(route('admin.users.edit',$user->id)); ?>" class="btn btn-primary">ویرایش</a>
                            
                            <form action="<?php echo e(route('admin.users.destroy',$user->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-danger">حذف</button>
                            </form>
                            <?php if($user->is_staff): ?>
                                <a href="<?php echo e(route('admin.createpermission',$user->id)); ?>" class="btn btn-warning mr-2">اعمال دسترسی</a>
                            <?php endif; ?>
                        </td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>

            </table>

            <?php echo e($users->render()); ?>

        </div>
        <!-- /.card-body -->
    </div>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/admin/user/alluser.blade.php ENDPATH**/ ?>