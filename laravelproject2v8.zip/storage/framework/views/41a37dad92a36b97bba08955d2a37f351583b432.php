<?php $__env->startComponent('admin.layouts.content',['title'=>' مدیریت گروه های دسترسی  ']); ?>


    <?php $__env->slot('breadcromp'); ?>

        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.')); ?>">صفحه ی اصلی</a></li>
        <li class="breadcrumb-item active"><a>مدیریت گروه های دسترسی</a></li>
    <?php $__env->endSlot(); ?>
    <div class="card">
        <div class="card-header ">


            <div class="card-tools ">
                <div class="input-group input-group-sm ">
                    <div class="d-flex align-items-center">
                        <?php if(request('search')): ?>
                            <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn btn-outline-danger  ml-2">بازگشت
                            </a>
                        <?php endif; ?>

                        <a href="<?php echo e(route('admin.roles.create')); ?>" class="btn btn-outline-info  ml-2">ساخت دسترسی
                            جدید</a>
                        <form action="" class="d-flex">
                            <input type="text" name="search" class="form-control float-right "
                                   placeholder="جستجو" value="<?php echo e(request('search')); ?>">
                            <div class="input-group-append">
                                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
        <!-- /.card-header -->
        <div class="card-body table-responsive p-0">
            <table class="table table-hover my-2">
                <tbody>
                <tr>

                    <th>نام گروه</th>

                    <th> توضیح گروه</th>
                    <th>اقدامات</th>
                </tr>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($role->name); ?></td>
                        <td><?php echo e($role->label); ?></td>


                        <td class="d-flex">
                            
                            <a href="<?php echo e(route('admin.roles.edit',$role->id)); ?>"
                               class="btn btn-primary">ویرایش</a>
                            <form method="post" action="<?php echo e(route('admin.roles.destroy',$role->id)); ?>" id="<?php echo e($role->id); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                            </form>
                            <a href="#"
                               class="btn btn-danger mr-2"
                               onclick="document.getElementById('<?php echo e($role->id); ?>').submit()">حذف</a>
                            


                        </td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>

            </table>

            <?php echo e($roles->render()); ?>

        </div>
        <!-- /.card-body -->
    </div>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/admin/roles/allroles.blade.php ENDPATH**/ ?>