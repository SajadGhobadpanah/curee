<?php $__env->startComponent('admin.layouts.content',['title'=>' ویرایش دسته  ']); ?>


    <?php $__env->slot('breadcromp'); ?>

        <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.')); ?>">صفحه ی اصلی</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.categories.index')); ?>">مدیریت دسته ها</a></li>
        <li class="breadcrumb-item"><a>ویرایش دسته </a></li>
    <?php $__env->endSlot(); ?>


    <div class="card card-info">
        <div class="card-header">
            <h3 class="card-title">فرم ویرایش دسته </h3>
        </div>
        <!-- /.card-header -->
        <!-- form start -->
        <form action="<?php echo e(route('admin.categories.update',$category->id)); ?>" method="post" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>
            <div class="card-body">

                <div class="form-group">
                    <label for="inputEmail3" class="col-sm-2 control-label">نام دسته</label>

                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="name" id="inputEmail3"
                               placeholder="نام دسته را وارد کنید" value="<?php echo e($category->name); ?>">
                    </div>
                </div>

                <?php if($category->parent !=0): ?>
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">نام والد</label>

                        <?php

                            $find=\App\Models\Category::find($category->parent);
                        ?>

                        <div class="col-sm-10">
                            <input type="text" class="form-control" value="<?php echo e($find->name); ?>"
                                   id="inputEmail3"
                                   disabled>
                        </div>
                    </div>


                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">تغییر والد</label>

                        <select name="parent" id="" class="form-control">
                            <?php $__currentLoopData = \App\Models\Category::where('parent',0)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    </div>

<?php endif; ?>
                    <!-- /.card-body -->
                    <div class="card-footer">
                        <button type="submit" class="btn btn-info">ویرایش</button>
                        <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-default">لغو</a>
                    </div>
            <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
        <!-- /.card-footer -->

    </div>


<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/admin/categories/editcategory.blade.php ENDPATH**/ ?>