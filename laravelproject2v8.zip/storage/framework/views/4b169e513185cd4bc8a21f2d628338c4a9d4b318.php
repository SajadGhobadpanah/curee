<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="text-center my-3">
<img src="<?php echo e($news->image); ?>" alt="" class="img-fluid" width="700px" height="200px"><br>
</div>

<div class="container">
<h5 class=""><?php echo e($news->title); ?></h5><br>

    <p class="text-justify"><?php echo $news->content; ?></p>
</div>



<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/home/newspage.blade.php ENDPATH**/ ?>