<?php $__env->startComponent('admin.layouts.content',['title'=>'صفحه ی اصلی']); ?>


    <?php $__env->slot('breadcromp'); ?>

        <li class="breadcrumb-item"><a href="#">صفحه ی اصلی</a></li>
    <?php $__env->endSlot(); ?>
    صفحه ی اصلی
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/admin/main.blade.php ENDPATH**/ ?>