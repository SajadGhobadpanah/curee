<?php $__env->startSection('title'); ?>

   ثبت نام
<?php $__env->stopSection(); ?>
<?php $__env->startSection('index'); ?>

        <div class="col-md-8">
            <div class="card">
                <div class="card-header" style="background: #86b8e1"><?php echo e(__('ثبت نام')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="row mb-3">
                            <label for="name" class="col-md-12 col-form-label text-md-start"><?php echo e(__('نام کاربری')); ?></label>

                            <div class="col-md-12">
                                <input id="name" type="text" class="form-control " name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>


                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="email" class="col-md-12 col-form-label text-md-start"><?php echo e(__('ایمیل')); ?></label>

                            <div class="col-md-12">
                                <input id="email" type="email" class="text-md-start form-control" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="phone" class="col-md-12 col-form-label text-md-start"><?php echo e(__('شماره تلفن')); ?></label>

                            <div class="col-md-12">
                                <input id="phone" type="text" class="text-md-start form-control" name="phone" value="<?php echo e(old('phone')); ?>" required autocomplete="email">

                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password" class="col-md-12 col-form-label text-md-start"><?php echo e(__('رمز عبور')); ?></label>

                            <div class="col-md-12">
                                <input id="password" type="password" class="form-control " name="password" required autocomplete="new-password">


                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password-confirm" class="col-md-12 col-form-label text-md-start"><?php echo e(__('تکرار رمز عبور ')); ?></label>

                            <div class="col-md-12">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

                        <div class="row mb-0">
                            <div class="col-md-12 text-center">
                                <button type="submit" class="btn btn-outline-blu">
                                    <?php echo e(__('ثبت نام')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                    <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/auth/register.blade.php ENDPATH**/ ?>