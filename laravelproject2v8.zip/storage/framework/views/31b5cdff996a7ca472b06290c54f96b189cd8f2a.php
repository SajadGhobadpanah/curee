<?php $__env->startSection('profileindex'); ?>
    <div class="col-md-12">
        <div class="card p-3">

            <div class="card-header" style="background: #86b8e1">

                فعال سازی شماره تلفن
            </div>

            <div class="card-body">
                <form action="" method="post">
                    <?php echo csrf_field(); ?>
                    <select name="type" id="" class="form-control">

                        <?php $__currentLoopData = config('twoFactor.types'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                value="<?php echo e($key); ?>" <?php echo e(old('type' == $key) || auth()->user()->hasTwoFactor($key)   ? 'selected' : ''); ?>><?php echo e($item); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select><br>

                    <input type="text" name="phone" class="form-control"
                           placeholder="شماره تلفن خود را وارد کنید..."
                           value="<?php echo e(auth()->user()->phone); ?>"><br>

                    <button type="submit" class="btn btn-outline-primary">ثبت</button>
                </form>

                <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('profile.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/profile/enablePhone.blade.php ENDPATH**/ ?>