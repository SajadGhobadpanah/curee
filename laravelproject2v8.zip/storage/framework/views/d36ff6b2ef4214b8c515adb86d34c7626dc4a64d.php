<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


    <div class="text-success">

        <?php echo e($category->name); ?>

    </div>


    <?php if($category->child->count()): ?>
-->
        <?php echo $__env->make('layouts.category',['categories'=>$category->child], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/layouts/category.blade.php ENDPATH**/ ?>