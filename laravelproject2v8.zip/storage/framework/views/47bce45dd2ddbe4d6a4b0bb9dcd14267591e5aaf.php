<?php $__env->startSection('title'); ?>

    فروشگاه
<?php $__env->stopSection(); ?>
<?php $__env->startSection('index'); ?>

    <div class="col-md-8 mr-2">


        <?php echo $__env->make('layouts.category',['categories'=>$categories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/home/categories.blade.php ENDPATH**/ ?>