<?php $__env->startSection('title'); ?>

    صفحه ی اصلی
<?php $__env->stopSection(); ?>
<?php $__env->startSection('index'); ?>
    <div class="col-md-8 mr-2">

        <div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">
            <div class="carousel-inner">
                <?php $__currentLoopData = \App\Models\Slide::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('about')); ?>">
                        <div class="carousel-item active">
                            <img src="<?php echo e($slide->image); ?>" class="d-block w-100" alt="">
                            <div class="carousel-caption d-none d-md-block">

                                <p style="color: black"><?php echo e($slide->alt); ?></p>
                            </div>
                        </div>
                    </a>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>
        <br>

        <h4 class="text-center">جدیدترین اخبار پزشکی</h4>


        <div class="row my-3 py-3 mb-3">
            <?php $__currentLoopData = \App\Models\News::latest()->paginate(12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6  my-4">
                    <a href="<?php echo e(route('newspage',$news->id)); ?>">
                        <img src="<?php echo e($news->image); ?>" alt="" class="img-fluid  " style="width: 100% ; height: 100%">
                        <br>
                        <div class="d-flex justify-content-between">
                            <span class="py-3"><?php echo e($news->title); ?> </span>
                            <span class="py-3"><?php echo e(jdate($news->created_at)->ago()); ?> </span>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


    </div>
    </div>
    </div>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/home/index.blade.php ENDPATH**/ ?>