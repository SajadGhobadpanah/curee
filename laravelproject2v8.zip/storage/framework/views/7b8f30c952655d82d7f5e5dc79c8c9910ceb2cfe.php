<!doctype html>
<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.rtl.min.css"
          integrity="sha384-+qdLaIRZfNu4cVPK/PxJJEy0B0f3Ugv8i482AKY7gwXwhaCroABd086ybrVKTa0q" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/profilestyle/css')); ?>">
</head>
<body>


<section x-data="toggleSidebar">


    <section x-cloak class="sidebar scroller" :class="open || 'inactive'">
        <div class="d-flex align-items-center justify-content-between justify-content-lg-center">
            <h3 class="fw-bold ">webprog.io</h3>
            <i @click="toggle" class="fs-1 bi bi-x text-sa d-lg-none"></i>

        </div>
        <div class=" mt-3 d-flex align-items-center hover-style">

            <ul class="list-unstyled  mb-0 dash-link">
                <li class="activee">
                    <a href="">
                        <i class="me-2 bi bi-grid-fill"></i>
                        <span class="mb-0">داشبورد</span>
                    </a>
                </li>

                <li x-data="dropdown" class="mt-3">


                    <div @click="toggle" class="d-flex justify-content-between align-items-center sa-link">

                        <div>
                            <i class="me-2 bi bi-bag"></i>

                            <span class="mb-0 ">فروشگاه</span>
                        </div>
                        <i class="bi bi-caret-down-fill mb-0 "></i>

                    </div>

                    <ul x-show="open" class="list-unstyled submenu lh-lg">

                        <li><a href="produce.html">
                                همه ی فروشگاه ها
                            </a>
                        </li>
                        <li><a href="">ویرایش فروشگاه
                            </a>
                        </li>
                        <li><a href="">

                                ایجاد فروشگاه
                            </a>
                        </li>
                    </ul>
                    </a>
                </li>
                <li x-data="dropdown" class="mt-3">


                    <div @click="toggle" class="d-flex justify-content-between align-items-center sa-link">

                        <div>
                            <i class="me-2 bi bi-bag"></i>

                            <span class="mb-0 ">محصولات</span>
                        </div>
                        <i class="bi bi-caret-down-fill mb-0 "></i>

                    </div>

                    <ul x-show="open" class="list-unstyled submenu lh-lg">

                        <li><a href="">
                                همه ی محصولات
                            </a>
                        </li>
                        <li><a href="">ویرایش محصولات
                            </a>
                        </li>
                        <li><a href="">

                                ایجاد محصولات
                            </a>
                        </li>
                    </ul>
                    </a>
                </li>
                <li x-data="dropdown" class="mt-3">


                    <div @click="toggle" class="d-flex justify-content-between align-items-center sa-link">

                        <div>
                            <i class="me-2 bi bi-bag"></i>

                            <span class="mb-0 ">محصولات</span>
                        </div>
                        <i class="bi bi-caret-down-fill mb-0 "></i>

                    </div>

                    <ul x-show="open" class="list-unstyled submenu lh-lg">

                        <li><a href="">
                                همه ی محصولات
                            </a>
                        </li>
                        <li><a href="">ویرایش محصولات
                            </a>
                        </li>
                        <li><a href="">

                                ایجاد محصولات
                            </a>
                        </li>
                    </ul>
                    </a>
                </li>
                <li x-data="dropdown" class="mt-3">


                    <div @click="toggle" class="d-flex justify-content-between align-items-center sa-link">

                        <div>
                            <i class="me-2 bi bi-bag"></i>

                            <span class="mb-0 ">محصولات</span>
                        </div>
                        <i class="bi bi-caret-down-fill mb-0 "></i>

                    </div>

                    <ul x-show="open" class="list-unstyled submenu lh-lg">

                        <li><a href="">
                                همه ی محصولات
                            </a>
                        </li>
                        <li><a href="">ویرایش محصولات
                            </a>
                        </li>
                        <li><a href="">

                                ایجاد محصولات
                            </a>
                        </li>
                    </ul>
                    </a>
                </li>
                <li x-data="dropdown" class="mt-3">


                    <div @click="toggle" class="d-flex justify-content-between align-items-center sa-link">

                        <div>
                            <i class="me-2 bi bi-bag"></i>

                            <span class="mb-0 ">تخفیفات</span>
                        </div>

                    </div>
                </li>
            </ul>
        </div>
        </div>
    </section>

    <?php echo $__env->yieldContent('profileindex'); ?>

</section>
<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/profile/layouts/headerprofile.blade.php ENDPATH**/ ?>