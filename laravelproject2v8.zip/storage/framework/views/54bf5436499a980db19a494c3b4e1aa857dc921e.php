<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="container">
    <div class="card my-3 p-3">
        <div class="card-header">
            <img class="mb-2 img-fluid text-center " src="<?php echo e($article->image); ?>" alt="" width="100%" >
        </div>
        <h5><?php echo e($article->title); ?></h5><br>


        <p class="text-justify"><?php echo $article->content; ?></p>
    </div>
</div>


<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/home/articlesingle.blade.php ENDPATH**/ ?>