<?php $__env->startComponent('admin.layouts.content',['title'=>' ایجاد دسته جدید ']); ?>


    <?php $__env->slot('breadcromp'); ?>

        <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.')); ?>">صفحه ی اصلی</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.categories.index')); ?>">مدیریت دسته ها</a></li>
        <li class="breadcrumb-item"><a>ایجاد دسته جدید</a></li>
    <?php $__env->endSlot(); ?>


    <div class="card card-info">
        <div class="card-header">
            <h3 class="card-title">فرم ایجاد دسته </h3>
        </div>
        <!-- /.card-header -->
        <!-- form start -->
        <form action="<?php echo e(route('admin.categories.store')); ?>" method="post" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <div class="card-body">

                <div class="form-group">
                    <label for="inputEmail3" class="col-sm-2 control-label">نام دسته</label>

                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="name" id="inputEmail3"
                               placeholder="نام دسته را وارد کنید">
                    </div>
                </div>

                <?php if(request('parent')): ?>

                    <?php

                        $parent=\App\Models\Category::find(request('parent'));
                    ?>
                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">نام والد</label>

                        <div class="col-sm-10">
                            <input type="text" class="form-control" value="<?php echo e($parent->name); ?>"
                                   id="inputEmail3"
                                   disabled>
                        </div>
                    </div>
                    <input type="hidden" name="parent" value="<?php echo e($parent->id); ?>">


            <?php endif; ?>



            <!-- /.card-body -->
                <div class="card-footer">
                    <button type="submit" class="btn btn-info">ایجاد</button>
                    <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-default">لغو</a>
                </div>
            <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
        <!-- /.card-footer -->

    </div>


<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/admin/categories/createcategory.blade.php ENDPATH**/ ?>