


<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <ul class="my-2">
        <li class="list-unstyled my-1" >

            <div class="d-flex">
                <span class="ml-2 my-2"><?php echo e($category->name); ?></span>
                <div>
                    <form action="<?php echo e(route('admin.categories.destroy',$category->id)); ?>" method="post"
                          id="<?php echo e($category->id); ?>">

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                    </form>
                    <a href="<?php echo e(route('admin.categories.edit',$category->id)); ?>" class="badge badge-primary">ویرایش</a>
                    <a href="#"
                       onclick="event.preventDefault();document.getElementById('<?php echo e($category->id); ?>').submit()"
                       class="badge badge-danger mx-2">حذف</a>
                    <a href="<?php echo e(route('admin.categories.create')); ?>?parent=<?php echo e($category->id); ?>" class="badge badge-warning">ایجاد
                        زیر دسته جدید</a>
                </div>

            </div>
            <ul>
                <?php if($category->child->count()): ?>
                    <li class="list-unstyled mr-4 mt-1">
                        <?php echo $__env->make('admin.categories.layout',['categories'=>$category->child], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </li>
                <?php endif; ?>
            </ul>
        </li>
    </ul>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/admin/categories/layout.blade.php ENDPATH**/ ?>