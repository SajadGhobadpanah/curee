<?php $__env->startComponent('admin.layouts.content',['title'=>' ویرایش و تایید نظر  ']); ?>


    <?php $__env->slot('breadcromp'); ?>

        <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.')); ?>">صفحه ی اصلی</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.permissions.index')); ?>">مدیریت نظرات </a></li>
        <li class="breadcrumb-item"><a>ویرایش نظر </a></li>
    <?php $__env->endSlot(); ?>


    <div class="card card-info">
        <div class="card-header">
            <h3 class="card-title">فرم ویرایش نظر </h3>
        </div>
        <!-- /.card-header -->
        <!-- form start -->
        <form action="<?php echo e(route('admin.updatecomment',$comment->id)); ?>" method="post" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="card-body">


                <div class="form-group">
                    <label for="" class="col-sm-2 control-label"> متن نظر</label>

                    <div class="col-sm-10">
                        <textarea name="comment" class="form-control" id="" cols="30"
                                  rows="10"><?php echo e($comment->comment); ?></textarea>
                    </div>
                </div>


            </div>
            <!-- /.card-body -->
            <div class="card-footer">
                <button type="submit" class="btn btn-info"> ویرایش و تایید</button>
                <a href="<?php echo e(route('admin.permissions.index')); ?>" class="btn btn-default">لغو</a>
            </div>
            <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
        <!-- /.card-footer -->

    </div>


<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/admin/comments/edit.blade.php ENDPATH**/ ?>