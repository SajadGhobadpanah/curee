<?php $__env->startComponent('admin.layouts.content',['title'=>' مدیریت دسته بندی ها ']); ?>


    <?php $__env->slot('breadcromp'); ?>

        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.')); ?>">صفحه ی اصلی</a></li>
        <li class="breadcrumb-item active"><a>مدیریت دسته بندی ها</a></li>
    <?php $__env->endSlot(); ?>
    <div class="card">
        <div class="card-header ">


            <div class="card-tools ">

                <div class="card-tools d-flex ">

                    <?php if(request('search')): ?>
                        <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-outline-danger  ml-2">بازگشت
                        </a>
                    <?php endif; ?>

                    <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-outline-info ذفد-سپ  ml-2">ساخت دسته
                        جدید</a>
                        <form action="" class="d-flex">
                            <input type="text" name="search" class="form-control float-right "
                                   placeholder="جستجو" value="<?php echo e(request('search')); ?>">
                            <div class="input-group-append">
                                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                            </div>
                        </form>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body table-responsive p-3">

                <?php echo $__env->make('admin.categories.layout',['categories'=>$categories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
            <!-- /.card-body -->
        </div>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/admin/categories/allcategories.blade.php ENDPATH**/ ?>