<section class="mt-4">
    <div class="container">
        <div class="row">

            <div class="col-md-4">
                <div class="card p-3 mb-2">
                    <div class="card-body">


                        <form class="d-flex mb-3" action="<?php echo e(route('search')); ?>">
                            <button type="submit" class="btn btn-outline-blu">جستجو</button>
                            <input class="form-control ms-2" type="text" name="search" placeholder="جستجو"
                                   aria-label="Search">

                        </form>
                        <?php if(auth()->check()): ?>

                            <span class="font-weight-bold text-danger "><?php echo e(auth()->user()->name); ?></span><span> ..عزیز خوش آمدید</span>
                            <a href="<?php echo e(route('profile')); ?>" class="btn btn-outline-blu mt-3 d-block "> پروفایل کاربری</a>

                            <?php if(auth()->user()->is_supervisor() || auth()->user()->is_staff()): ?>
                                <a href="<?php echo e(route('admin.')); ?>" class="btn btn-outline-blu mt-3 d-block "> بخش مدیریت</a>
                            <?php endif; ?>
                            <form action="<?php echo e(route('logout')); ?>" method="post" id="<?php echo e(auth()->user()->id); ?>">
                                <?php echo csrf_field(); ?>

                            </form>
                            <a href=""
                               onclick="event.preventDefault();document.getElementById('<?php echo e(auth()->user()->id); ?>').submit()"
                               class="btn btn-danger mt-3 d-block "> خروج</a>


                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-blu mt-3 d-block "> ورود به سایت</a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card  mb-2">
                    <div class="card-header text-center">
                        مقالات
                    </div>
                    <?php $__currentLoopData = \App\Models\Article::all()->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card-body d-flex align-items-center galeri1 position-relative">


                            <img src="<?php echo e($article->image); ?>" alt="" class="img-fluid galeri-img1 " width="100px"
                                 height="200px">
                            <div class="p-3">
                                <!--                            <p>     -->
                                <a href="<?php echo e(route('article.single',$article->id)); ?>">
                                    <?php echo e($article->title); ?>

                                </a>
                                <!--                            </p>-->
                                <!--                            <span>1 ساعت پیش</span>-->
                            </div>


                        </div>
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <span class="text-center pb-3"><a href="<?php echo e(route('articles')); ?>">همه مقالات</a></span>

                </div>
                <div class="card  mb-2">
                    <div class="card-header text-center">
                        محصولات
                    </div>
                    <?php $__currentLoopData = \App\Models\Product::all()->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card-body d-flex align-items-center galeri1 position-relative">


                            <img src="<?php echo e($product->image); ?>" alt="" class="img-fluid galeri-img1 " width="100px"
                                 height="200px">
                            <div class="p-3">
                                <!--                            <p>     -->
                                <a href="<?php echo e(route('singleproduct',$product->id)); ?>">
                                    <?php echo e($product->title); ?>

                                </a>
                                <!--                            </p>-->
                                <!--                            <span>1 ساعت پیش</span>-->
                            </div>


                        </div>
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <span class="text-center pb-3"><a href="<?php echo e(route('products')); ?>">همه محصولات</a></span>

                </div>
            </div>

<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>