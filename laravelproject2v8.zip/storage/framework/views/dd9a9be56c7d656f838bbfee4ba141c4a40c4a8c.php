<?php $__env->startComponent('admin.layouts.content',['title'=>' مدیریت تخفیفات ']); ?>


    <?php $__env->slot('breadcromp'); ?>

        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.')); ?>">صفحه ی اصلی</a></li>
        <li class="breadcrumb-item active"><a>مدیریت تخفیفات </a></li>
    <?php $__env->endSlot(); ?>
    <div class="card">
        <div class="card-header ">


            <div class="card-tools ">
                <div class="input-group input-group-sm ">
                    <div class="d-flex align-items-center">
                        <?php if(request('search')): ?>
                            <a href="<?php echo e(route('admin.discounts.index')); ?>" class="btn btn-outline-danger  ml-2">بازگشت
                            </a>
                        <?php endif; ?>

                        <a href="<?php echo e(route('admin.discounts.create')); ?>" class="btn btn-outline-info  ml-2">ساخت کد تخفیف
                            جدید</a>
                        <form action="" class="d-flex">
                            <input type="text" name="search" class="form-control float-right "
                                   placeholder="جستجو" value="<?php echo e(request('search')); ?>">
                            <div class="input-group-append">
                                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
        <!-- /.card-header -->
        <div class="card-body table-responsive p-0">
            <table class="table table-hover my-2">
                <tbody>
                <tr>

                    <th> عنوان کد</th>

                    <th> درصد تخفیف</th>
                    <th> مدت زمان</th>
                    <th> کاربران مجاز</th>
                    <th> محصولات مورد نظر</th>
                    <th> دسته های مورد نظر</th>
                    <th>اقدامات</th>
                </tr>
                <?php $__currentLoopData = $discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($discount->code); ?></td>
                        <td><?php echo e($discount->percent); ?></td>
                        <td><?php echo e(jdate($discount->expired_at)); ?></td>
                        <td><?php echo e($discount->users->count() ? $discount->users->pluck('name')->join(',') : 'همه ی کاربران'); ?></td>
                        <td><?php echo e($discount->products->count() ? $discount->products->pluck('title')->join(',') : 'همه ی محصولات'); ?></td>
                        <td><?php echo e($discount->categories->count() ? $discount->categories->pluck('name')->join(',') : 'همه ی دسته ها'); ?></td>


                        <td class="d-flex">
                            
                            <a href="<?php echo e(route('admin.discounts.edit',$discount->id)); ?>"
                               class="btn btn-primary">ویرایش</a>
                            <form method="post" action="<?php echo e(route('admin.discounts.destroy',$discount->id)); ?>"
                                  id="<?php echo e($discount->id); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                            </form>
                            <a href="#"
                               class="btn btn-danger mr-2"
                               onclick="document.getElementById('<?php echo e($discount->id); ?>').submit()">حذف</a>
                            


                        </td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>

            </table>

            <?php echo e($discounts->render()); ?>

        </div>
        <!-- /.card-body -->
    </div>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\Modules/Discount\Resources/views/admin/discounts/alldiscount.blade.php ENDPATH**/ ?>