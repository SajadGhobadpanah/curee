<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('profile.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<section x-data="toggleSidebar">

    <?php echo $__env->make('profile.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content" style="height: 100vh">

        <div class="container-fluid">
            <div class="row p-lg-5 gy-3">
                <div class="col-lg-9">
                    <div class="row gy-4">


                        <?php echo $__env->yieldContent('profileindex'); ?>


                    </div>
</section>
<?php echo $__env->make('profile.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/profile/index.blade.php ENDPATH**/ ?>