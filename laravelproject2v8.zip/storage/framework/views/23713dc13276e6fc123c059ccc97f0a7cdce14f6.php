<?php $__env->startSection('profileindex'); ?>


    <h1>sakalskals</h1>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('profile.indexprofile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/profile/mailprofile.blade.php ENDPATH**/ ?>