<script src="https://cdn.jsdelivr.net/npm/@srexi/purecounterjs/dist/purecounter_vanilla.js"></script>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
        crossorigin="anonymous"></script>
<script defer src="https://unpkg.com/alpinejs@3.7.0/dist/cdn.min.js"></script>
<script>
    document.addEventListener('alpine:init', () => {
        Alpine.data('toggleSidebar', () => ({
            open: window.innerWidth <= 992 ? false : true,

            toggle() {
                this.open = !this.open
            }
        })),
            Alpine.data('dropdown', () => ({
                open: false,

                toggle() {
                    this.open = !this.open
                }
            }))
    })

</script>
<!-- Resources -->
<script src="https://cdn.amcharts.com/lib/4/core.js"></script>
<script src="https://cdn.amcharts.com/lib/4/charts.js"></script>
<script src="https://cdn.amcharts.com/lib/4/themes/animated.js"></script>

</body>
</html>
<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/profile/layouts/footerprofile.blade.php ENDPATH**/ ?>