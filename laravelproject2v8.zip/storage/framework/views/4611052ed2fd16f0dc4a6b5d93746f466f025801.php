<?php $__env->startComponent('admin.layouts.content',['title'=>' مدیریت  پرداخت های سفارش ']); ?>


    <?php $__env->slot('breadcromp'); ?>

        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.')); ?>">صفحه ی اصلی</a></li>
        <li class="breadcrumb-item active"><a>مدیریت سفارشات</a></li>
    <?php $__env->endSlot(); ?>
    <div class="card">
        <div class="card-header ">
            <h3 class="card-title"> جدول پرداخت های سفارش
            </h3>

            <div class="card-tools ">
                <div class="input-group input-group-sm ">
                    <div class="d-flex align-items-center">
                        <?php if(request('search')): ?>
                            <a href="<?php echo e(route('admin.orders.index'). "?type=$order->status"); ?>"
                               class="btn btn-outline-danger  ml-2">بازگشت
                            </a>
                        <?php endif; ?>


                        <form action="" class="d-flex">
                            <input type="text" name="search" class="form-control float-right "
                                   placeholder="جستجو" value="<?php echo e(request('search')); ?>">
                            <div class="input-group-append">
                                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
        <!-- /.card-header -->
        <div class="card-body table-responsive p-0">
            <table class="table table-hover">
                <tbody>
                <tr>

                    <th>کد پرداخت</th>
                    <th>شماره پرداخت</th>

                    <th>  وضعیت پرداخت</th>
                    <th>  زمان ثبت پرداخت</th>



                </tr>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($order->id); ?></td>
                        <td><?php echo e($order->res_number); ?></td>
                        <td><?php echo e($order->status == 0 ? 'پرداخت ناموفق' : 'پرداخت موفق'); ?></td>

                        <td><?php echo e(jdate($order->created_at)); ?></td>



















                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>

            </table>

            <?php echo e($orders->render()); ?>

        </div>
        <!-- /.card-body -->
    </div>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/admin/order/payments.blade.php ENDPATH**/ ?>