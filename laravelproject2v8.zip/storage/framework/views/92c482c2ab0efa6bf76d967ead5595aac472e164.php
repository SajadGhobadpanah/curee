<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === ''): ?>
    سایت من
<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>