<?php $__env->startComponent('admin.layouts.content',['title'=>' ایجاد کد تخفیف جدید ']); ?>


    <?php $__env->slot('breadcromp'); ?>

        <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.')); ?>">صفحه ی اصلی</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.discounts.index')); ?>">مدیریت تخفیفات</a></li>
        <li class="breadcrumb-item"><a>ایجاد کد تخفیف جدید</a></li>
    <?php $__env->endSlot(); ?>
    <?php $__env->slot('script'); ?>
        <script>
            $('#users').select2({
                'placeholder': 'کاربر  مورد نظر را انتخاب کنید'
            })

            $('#products').select2({
                'placeholder': 'محصول  مورد نظر را انتخاب کنید'
            })

            $('#categories').select2({
                'placeholder': 'محصول  مورد نظر را انتخاب کنید'
            })
        </script>
    <?php $__env->endSlot(); ?>

    <div class="card card-info">
        <div class="card-header">
            <h3 class="card-title">فرم ایجاد کد تخفیف </h3>
        </div>
        <!-- /.card-header -->
        <!-- form start -->
        <form action="<?php echo e(route('admin.discounts.store')); ?>" method="post" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <div class="card-body">

                <div class="form-group">
                    <label for="inputEmail3" class="col-sm-2 control-label">عنوان کد تخفیف</label>

                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="code" id="inputEmail3"
                               placeholder="عنوان کد تخفیف را اینجا وارد کنید" value="<?php echo e(old('code')); ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label for="" class="col-sm-2 control-label">درصد تخفیف</label>

                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="percent" id="inputEmail3"
                               placeholder="درصد تخفیف را اینجا وارد کنید" value="<?php echo e(old('percent')); ?>"></div>
                </div>
                <div class="form-group">
                    <label for="" class="col-sm-2 control-label"> کاربران مجاز</label>
                    <div class="col-sm-10">
                        <select name="users[]" id="users" class="form-control" multiple>

                            <option value="">همه ی کاربران</option>
                            <?php $__currentLoopData = \App\Models\User::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label for="" class="col-sm-2 control-label">محصولات مجاز</label>
                    <div class="col-sm-10">
                        <select name="products[]" id="products" class="form-control" multiple>

                            <option value="">همه ی محصولات</option>
                            <?php $__currentLoopData = \App\Models\Product::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($product->id); ?>"><?php echo e($product->title); ?></option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </select>
                    </div>
                </div>



                <div class="form-group">
                    <label for="" class="col-sm-2 control-label">دسته های مجاز</label>
                    <div class="col-sm-10">
                        <select name="categories[]" id="categories" class="form-control" multiple>

                            <option value="">همه ی دسته ها</option>
                            <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </select>
                    </div>
                </div>

                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label"> زمان مجاز استفاده کد تخفیف</label>

                        <div class="col-sm-10">
                            <input type="datetime-local" class="form-control" name="expired_at" id="inputEmail3"
                                   placeholder="زمان مجاز کد تخفیف را اینجا وارد کنید" value="<?php echo e(old('expired_at')); ?>">
                        </div>
                    </div>


                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                    <button type="submit" class="btn btn-info">ایجاد</button>
                    <a href="<?php echo e(route('admin.discounts.index')); ?>" class="btn btn-default">لغو</a>
                </div>
            <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
        <!-- /.card-footer -->

    </div>


<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\Modules/Discount\Resources/views/admin/discounts/creatediscount.blade.php ENDPATH**/ ?>