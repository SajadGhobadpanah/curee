<?php $__env->startSection('profileindex'); ?>

    <div class="card-body table-responsive p-0">
        <table class="table table-hover">
            <tbody>
            <tr>

                <th> شماره سفارش</th>

                <th> تاریخ ثبت</th>
                <th> وضعیت سفارش</th>
                <th> کد رهگیری</th>
                <th>اقدامات</th>
            </tr>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($order->id); ?></td>
                    <td><?php echo e(jdate($order->created_at)); ?></td>

                    <td>

                        <?php switch($order->status):

                            case ('unpaid'): ?>
                            <div class="alert-danger">پرداخت نشده</div>
                            <?php break; ?>
                            <?php case ('paid'): ?>
                            <div class="alert-success">پرداخت شده</div>
                            <?php break; ?>

                            <?php case ('preparation'): ?>
                            در حال آماده سازی
                            <?php break; ?>

                            <?php case ('posted'): ?>
                            پست شده
                            <?php break; ?>


                            <?php case ('received'): ?>
                            دریافت شده
                            <?php break; ?>
                            <?php case ('canceled'): ?>
                            کنسل شده
                            <?php break; ?>



                        <?php endswitch; ?>


                    </td>
                    <td><?php echo e($order->tracking_serial ?? 'کد رهگیری  ثبت نشده است!'); ?></td>
                    <td class="d-flex">
                        
                        <a href="<?php echo e(route('profile.orders.detail',$order->id)); ?>"
                           class="btn btn-primary btn-sm ml-2">جزییات سفارش</a>
                        <?php if($order->status == 'unpaid'): ?>
                            <a href="<?php echo e(route('profile.orders.payment',$order->id)); ?>" class="btn btn-secondary btn-sm ">پرداخت </a>

                        <?php endif; ?>
                    </td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($orders->render()); ?>


            </tbody>

        </table>


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('profile.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/profile/orders.blade.php ENDPATH**/ ?>