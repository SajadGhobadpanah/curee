<?php $__env->startComponent('admin.layouts.content',['title'=>' مدیریت درباره ما   ']); ?>


    <?php $__env->slot('breadcromp'); ?>

        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.')); ?>">صفحه ی اصلی</a></li>
        <li class="breadcrumb-item active"><a> درباره ما </a></li>
    <?php $__env->endSlot(); ?>

    <?php $__env->slot('script'); ?>

        <script src="<?php echo e(asset('js/ckeditor/ckeditor.js')); ?>"></script>
        <script>
            CKEDITOR.replace('description', {filebrowserImageBrowseUrl: '/file-manager/ckeditor'});

            document.addEventListener("DOMContentLoaded", function () {

                document.getElementById('button-image').addEventListener('click', (event) => {
                    event.preventDefault();

                    window.open('/file-manager/fm-button', 'fm', 'width=1000,height=800');
                });
            });

            // set file link
            function fmSetLink($url) {
                document.getElementById('image_label').value = $url;
            }
        </script>

    <?php $__env->endSlot(); ?>
    <div class="card card-info">
        <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form action="<?php echo e(route('admin.about.update',$about->id)); ?>" method="post" class="form-horizontal">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <div class="card-body">


                    <div class="form-group">
                        <label for="" class="col-sm-2 control-label">متن </label>

                        <div class="col-sm-10">
                        <textarea name="about" class="form-control" id="description" cols="30"
                                  rows="10"><?php echo e($about->about); ?></textarea>
                        </div>

                    </div>

                    <button class="btn btn-primary">ذخیره</button>
                </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </form>

    <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/admin/about/about.blade.php ENDPATH**/ ?>