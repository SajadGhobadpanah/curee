<?php $__env->startComponent('admin.layouts.content',['title'=>' مدیریت  محصولات ']); ?>


    <?php $__env->slot('breadcromp'); ?>

        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.')); ?>">صفحه ی اصلی</a></li>
        <li class="breadcrumb-item active"><a>مدیریت محصولات</a></li>
    <?php $__env->endSlot(); ?>
    <div class="card">
        <div class="card-header ">


            <div class="card-tools ">
                <div class="input-group input-group-sm ">
                    <div class="d-flex align-items-center">
                        <?php if(request('search')): ?>
                            <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-outline-danger  ml-2">بازگشت
                            </a>
                        <?php endif; ?>

                        <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-outline-info  ml-2">ساخت محصول
                            جدید</a>
                        <form action="" class="d-flex">
                            <input type="text" name="search" class="form-control float-right "
                                   placeholder="جستجو" value="<?php echo e(request('search')); ?>">
                            <div class="input-group-append">
                                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
        <!-- /.card-header -->
        <div class="card-body table-responsive p-0">
            <table class="table table-hover my-2">
                <tbody>
                <tr>

                    <th>شماره محصول</th>
                    <th>عنوان محصول</th>
                    <th>قیمت محصول</th>
                    <th>موجودی محصول</th>
                    <th>درصد تخفیف</th>


                    <th>اقدامات</th>
                </tr>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($product->id); ?></td>
                        <td><?php echo e($product->title); ?></td>
                        <td><?php echo e($product->price); ?></td>
                        <td><?php echo e($product->inventory); ?></td>
                        <td><?php echo e($product->percent); ?></td>


                        <td class="d-flex">
                            
                            <a href="<?php echo e(route('admin.products.edit',$product->id)); ?>"
                               class="btn btn-primary">ویرایش</a>
                            <form method="post" action="<?php echo e(route('admin.products.destroy',$product->id)); ?>"
                                  id="<?php echo e($product->id); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                            </form>
                            <a href="#"
                               class="btn btn-danger mx-2"
                               onclick="document.getElementById('<?php echo e($product->id); ?>').submit()">حذف</a>
                            

                            <a href="<?php echo e(route('admin.product.gallery.index',$product->id)); ?>"
                               class="btn btn-warning">گالری تصاویر</a>
                        </td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>

            </table>

            <?php echo e($products->render()); ?>

        </div>
        <!-- /.card-body -->
    </div>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/admin/products/allproducts.blade.php ENDPATH**/ ?>