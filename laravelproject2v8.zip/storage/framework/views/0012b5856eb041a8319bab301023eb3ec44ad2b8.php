<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $('#sendComment').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget)
            let parent_id = button.data('id');

            var modal = $(this)
            modal.find('input[name="parent_id"]').val(parent_id)

        });

    </script>
<?php $__env->stopSection(); ?>

<?php if(auth()->guard()->check()): ?>
    <div class="modal fade" id="sendComment">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">ارسال نظر</h5>
                    <button type="button" class="close mr-auto ml-0" data-bs-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('storecomment')); ?>" method="post" id="sendCommentForm">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <input type="hidden" name="commentable_id" value="<?php echo e($product->id); ?>">
                        <input type="hidden" name="commentable_type" value="<?php echo e(get_class($product)); ?>">
                        <input type="hidden" name="parent_id" value="0">

                        <div class="form-group">
                            <label for="message-text" class="col-form-label">پیام دیدگاه:</label>
                            <textarea name="comment" class="form-control" id="message-text"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">لغو</button>
                        <button type="submit" class="btn btn-primary">ارسال نظر</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endif; ?>

<div class="container">
    <div class="col-md-10 mr-2">
        <h4 class="text-center"><?php echo e($product->title); ?></h4><br>
        <img src="/images/7.jpg" alt="" width="100%">
        <br>
        <p class="text-justify my-3"><?php echo $product->content; ?></p>


        <div class="text-center my-3">
            <?php if($product->percent): ?>
                <sapn
                    style="background: #d90b31;color: #fff; padding: 2px;border-radius: 30%"><?php echo e($product->percent); ?> </sapn>
                <span>%</span>
            <?php endif; ?>
            <br>
            <div class="mt-3">
                <span class="py-3"><?php echo e($product->price); ?></span><br><br>

                <br>
                <?php if($product->attributes->count()): ?>
                    <h5>ویژگی ها</h5>
                    <?php $__currentLoopData = $product->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <span class="text"><?php echo e($attr->name); ?></span>

                        <?php $__currentLoopData = $attr->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <span class="text-danger"><?php echo e($val->value); ?></span><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <br>
                <?php if($product->galleries->count()): ?>

                <h5>تصاویر</h5>
                    <?php $__currentLoopData = $product->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url($gal->image)); ?>" target="_blank">
                            <img class="img-fluid mx-1" src="<?php echo e($gal->image); ?>" alt="" width="100px">
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <br>
                    <br>
                <?php endif; ?>
                <?php if(\App\Helper\Cart\Cart::count($product) < $product->inventory): ?>
                    <a href="<?php echo e(route('addToCart',$product->id)); ?>" class="btn btn-outline-blu"> افزودن به سید
                        خرید</a>
                <?php else: ?>

                    <span class="alert-primary alert">این محصول موجود نمیباشد!</span>

                <?php endif; ?>
            </div>
        </div>


        <div class="card p-3 text-center mb-3  mt-4">

            <?php if(auth()->guard()->guest()): ?>
                <div class="alert alert-danger">برای ثبت نظر لطفا وارد سایت شوید.</div>
            <?php endif; ?>
            <div class="d-sm-flex d-block align-items-center justify-content-between align-content-center">
                <h4 class="mt-4 mb-4">بخش نظرات</h4>
                <?php if(auth()->guard()->check()): ?>
                    <span class="btn btn-sm btn-outline-blu mb-4 mb-sm-0" data-bs-toggle="modal"
                          data-bs-target="#sendComment"
                          data-id="0">ثبت نظر جدید</span>
                <?php endif; ?>
            </div>

        </div>

        <?php echo $__env->make('layouts.comment',['comments'=>$product->comments()->where('parent_id',0)->where('approved',1)->get()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    </div>
</div>
</div>
</div>

<?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/home/singleproduct.blade.php ENDPATH**/ ?>