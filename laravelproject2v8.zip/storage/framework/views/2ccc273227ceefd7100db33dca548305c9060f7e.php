

    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card p-3 d-flex justify-content-between  mb-2 ">
            <div style="float: right" class="d-flex align-items-center">
                <img src="<?php echo e($comment->user->image); ?>" alt="" class="img-rounded img-thumbnail "
                     style="float: right;height: 90px;width: 80px">
                <div class="m-2">
                    <span style="float: right"><?php echo e($comment->user->name); ?>  </span><br>
                    <span style="float: right"><?php echo e(jdate($comment->created_at)->ago()); ?></span>
                </div>
            </div>
            <div>
                <p class="p-3"><?php echo e($comment->comment); ?></p>
                <?php if(auth()->guard()->check()): ?>
                    <span class="btn btn-sm btn-outline-blu" data-bs-toggle="modal" data-bs-target="#sendComment"
                          data-id="<?php echo e($comment->id); ?>" style="float: left">پاسخ</span>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-body">
            <?php echo $__env->make('layouts.comment',['comments'=>$comment->child->where('approved',1)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/layouts/comment.blade.php ENDPATH**/ ?>