<?php $__env->startSection('title'); ?>

    ورود
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://www.google.com/recaptcha/api.js?hl=fa" async defer></script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('index'); ?>

    <div class="col-md-8">
        <div class="card">
            <div class="card-header" style="background: #86b8e1"><?php echo e(__('ورود')); ?></div>

            <div class="card-body">
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="row mb-3">
                        <label for="email" class="col-md-12 col-form-label text-md-start"><?php echo e(__('ایمیل')); ?></label>

                        <div class="col-md-12">
                            <input id="email" type="email"
                                   class="text-md-start form-control " name="email"
                                   value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>


                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="password"
                               class="col-md-12 col-form-label text-md-start"><?php echo e(__('رمز عبور')); ?></label>

                        <div class="col-md-12">
                            <input id="password" type="password"
                                   class="form-control " name="password" required
                                   autocomplete="current-password">

                        </div>
                    </div>
                    <div class="g-recaptcha" data-sitekey="<?php echo e(env('RECAPTCAH_SITE_KEY')); ?>"></div>


                    <div class="row mb-3">
                        <div class="col-md-12 d-flex ">
                            <label class="form-check-label mx-2" for="remember">
                                <?php echo e(__('مرا به خاطر بسپار')); ?>

                            </label>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="remember"
                                       id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>


                            </div>
                        </div>
                    </div>


                    <div class="row mb-0">
                        <div class="col-md-6 offset-md-4 ">
                            <button type="submit" class="btn btn-outline-blu px-4">
                                <?php echo e(__('ورود')); ?>

                            </button>

                            <?php if(Route::has('password.request')): ?>
                                <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                    <?php echo e(__('فراموشی رمز')); ?>

                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-md-6">
                            <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-blu px-4">
                                <?php echo e(__('ثبت نام')); ?>

                            </a>
                            <a href="<?php echo e(route('login.google')); ?>" class="btn btn-outline-blu">ورود با حساب گوگل</a>
                        </div>

                    </div>
                </form>

                <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/auth/login.blade.php ENDPATH**/ ?>