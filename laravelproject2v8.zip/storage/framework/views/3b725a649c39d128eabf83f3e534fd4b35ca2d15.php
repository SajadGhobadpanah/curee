<?php $__env->startSection('title'); ?>

    تایید ایمیل
<?php $__env->stopSection(); ?>
<?php $__env->startSection('index'); ?>

    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><?php echo e(__('تایید ایمیل')); ?></div>

            <div class="card-body">
                <?php if(session('resent')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(__('   یک پیام متنی به آدرس ایمیل شما ارسال شد! ')); ?>

                    </div>
                <?php endif; ?>


                <?php echo e(__('لطفا ابتدا وارد ایمیل خود شده و پیام ارسالی از این قسمت را تایید کنید !')); ?>,
                <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit"
                            class="btn btn-link p-0 m-0 align-baseline"><?php echo e(__('درخواست  ایمیل فعال سازی ')); ?></button>
                    .
                </form>
            </div>
        </div>
    </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/auth/verify.blade.php ENDPATH**/ ?>