<?php $__env->startComponent('admin.layouts.content',['title'=>' ایجاد دسترسی جدید ']); ?>


    <?php $__env->slot('breadcromp'); ?>

        <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.')); ?>">صفحه ی اصلی</a></li>
        <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.permissions.index')); ?>">مدیریت دسترسی ها</a></li>
        <li class="breadcrumb-item"><a>ایجاد دسترسی جدید</a></li>
    <?php $__env->endSlot(); ?>


    <div class="card card-info">
        <div class="card-header">
            <h3 class="card-title">فرم ایجاد دسترسی </h3>
        </div>
        <!-- /.card-header -->
        <!-- form start -->
        <form action="<?php echo e(route('admin.permissions.store')); ?>" method="post" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <div class="card-body">

                <div class="form-group">
                    <label for="inputEmail3" class="col-sm-2 control-label">نام دسترسی</label>

                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="name" id="inputEmail3"
                               placeholder="نام دسترسی را وارد کنید">
                    </div>
                </div>

                <div class="form-group">
                    <label for="" class="col-sm-2 control-label">توضیح دسترسی</label>

                    <div class="col-sm-10">
                        <textarea name="label" class="form-control"  id="" cols="30" rows="10"></textarea>
                    </div>
                </div>


            </div>
            <!-- /.card-body -->
            <div class="card-footer">
                <button type="submit" class="btn btn-info">ایجاد</button>
                <a href="<?php echo e(route('admin.permissions.index')); ?>" class="btn btn-default">لغو</a>
            </div>
            <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
        <!-- /.card-footer -->

    </div>


<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/admin/permission/createpermission.blade.php ENDPATH**/ ?>