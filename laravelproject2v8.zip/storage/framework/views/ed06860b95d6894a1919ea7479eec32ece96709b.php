<?php $__env->startSection('profileindex'); ?>

    <div class="card-body table-responsive p-0">
        <table class="table table-hover">
            <tbody>
            <tr>

                <th> شماره محصول</th>

                <th> عنوان محصول</th>
                <th> تعداد سفارش</th>
                <th> قیمت بدون تخفیف</th>

                
            </tr>
            <?php $__currentLoopData = $orderdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($order->id); ?></td>
                    <td><?php echo e($order->title); ?></td>
                    <td><?php echo e($order->pivot->quantity); ?></td>
                    <td><?php echo e($order->pivot->quantity * $order->price); ?></td>

                    
                    
                    
                    
                    

                    


                    
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php echo e($orderdetails->render()); ?>

            </tbody>

        </table>


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('profile.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/profile/orderdetail.blade.php ENDPATH**/ ?>