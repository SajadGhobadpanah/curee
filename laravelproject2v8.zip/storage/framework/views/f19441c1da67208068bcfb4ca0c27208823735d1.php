<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>