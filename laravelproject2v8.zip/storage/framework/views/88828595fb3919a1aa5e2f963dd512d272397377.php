<?php $__env->startSection('profileindex'); ?>

    <div class="row">

       <h5><?php echo e(auth()->user()->name); ?> عزیز به قسمت پروفایل کاربری خود خوش آمدید</h5>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('profile.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/profile/main.blade.php ENDPATH**/ ?>