<?php $__env->startComponent('admin.layouts.content',['title'=>' اعمال دسترسی برای کاربران مدیر ']); ?>


    <?php $__env->slot('breadcromp'); ?>

        <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.')); ?>">صفحه ی اصلی</a></li>
        <li class="breadcrumb-item"><a>اعمال دسترسی برای کاربران مدیر</a></li>
    <?php $__env->endSlot(); ?>

    <?php $__env->slot('script'); ?>
        <script>
            $('#permissions').select2({
                'placeholder' : 'دسترسی مورد نظر را انتخاب کنید'
            })
            $('#roles').select2({
                'placeholder' : 'گروه مورد نظر را انتخاب کنید'
            })
        </script>
    <?php $__env->endSlot(); ?>
    <div class="card card-info">
        <div class="card-header">
            <h3 class="card-title">فرم ایجاد </h3>
        </div>
        <!-- /.card-header -->
        <!-- form start -->
        <form action="<?php echo e(route('admin.storepermissios',$user->id)); ?>" method="post" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <div class="card-body">

                <div class="form-group">
                    <label for="" class="col-sm-2 control-label"> لیست دسترسی ها</label>

                    <select name="permissions[]" id="permissions" class="form-control" multiple>
                        <?php $__currentLoopData = \App\Models\Permission::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option
                                value="<?php echo e($permission->id); ?>" <?php echo e(in_array($permission->id , $user->permissions->pluck('id')->toArray()) ? 'selected' :''); ?>><?php echo e($permission->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>


                </div>


                <div class="form-group">
                    <label for="" class="col-sm-2 control-label"> لیست گروه ها</label>

                    <select name="roles[]" id="roles" class="form-control" multiple>
                        <?php $__currentLoopData = \App\Models\Role::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option
                                value="<?php echo e($role->id); ?>" <?php echo e(in_array($role->id , $user->roles->pluck('id')->toArray()) ? 'selected' :''); ?>><?php echo e($role->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>


                </div>
            </div>
            <!-- /.card-body -->
            <div class="card-footer">
                <button type="submit" class="btn btn-info">اعمال</button>

            </div>
            <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
        <!-- /.card-footer -->

    </div>


<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\ffd\Desktop\laravelproject2v8\resources\views/admin/addPermission/create.blade.php ENDPATH**/ ?>