<?php

return [
    'name' => 'Discount'
];
